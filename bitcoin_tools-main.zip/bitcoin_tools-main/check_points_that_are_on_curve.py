#p = 397
p = 97
x = 0
y = 0
xarr = list()
yarr = list()
counter = 1
for x in range(0,p):
    for y in range(0,p):
        if (y**2) % p == (x**3 + 7) % p:#(y**2) % p == (x**3 + 2*x + 2) % p
            print(f"{counter}:({x},{y})")
            counter += 1
            xarr.append(x)
            yarr.append(y)
print(f'prime(p)={p} order(n)={counter}')
#print(xarr)
#print(yarr)
'''
print("Report:")
for i in range(0,len(yarr)):
    counter = 0
    for itemy in yarr:
        if itemy == i:
            print(f"{xarr[counter]} {yarr[counter]}")
        counter += 1

'''
