# bitcoin_tools
 Various python scripts for secp256k1
